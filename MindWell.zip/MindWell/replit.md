# StressSense - Academic Stress Management Platform

## Overview

StressSense is a comprehensive web application designed to help students manage academic stress through mood tracking, AI-powered insights, and personalized coping strategies. The platform combines journaling capabilities, sentiment analysis, and an AI chatbot companion to provide students with tools for mental wellness during their academic journey.

The application follows a modern full-stack architecture with a React frontend, Express.js backend, and PostgreSQL database, all designed to provide real-time stress management support with data-driven insights.

## Recent Changes (January 31, 2025)

✓ **Full Application Setup Complete** - All core features implemented and working
✓ **Database Integration** - PostgreSQL database configured with proper schema
✓ **Authentication System** - Replit Auth fully integrated with session management
✓ **AI Services** - OpenAI GPT-4o integrated for chatbot and insights
✓ **All TypeScript Errors Resolved** - Clean codebase with no compilation issues
✓ **Application Running Successfully** - Server started on port 5000

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety and modern development
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management and caching
- **UI Components**: Radix UI primitives with Tailwind CSS for consistent, accessible design
- **Styling**: Tailwind CSS with CSS variables for theming and shadcn/ui component system
- **Build Tool**: Vite for fast development and optimized production builds

### Backend Architecture
- **Framework**: Express.js with TypeScript for API development
- **Authentication**: Replit Auth with OpenID Connect for secure user authentication
- **Session Management**: Express sessions with PostgreSQL store for persistent login sessions
- **API Design**: RESTful endpoints with consistent error handling and logging middleware
- **Request Validation**: Zod schemas for runtime type checking and data validation

### Database Architecture
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Schema Design**: Relational model with tables for users, journal entries, chat messages, coping sessions, and authentication sessions
- **Data Relationships**: Foreign key constraints linking user data across all feature tables
- **Migration Strategy**: Drizzle migrations for schema versioning and deployment

### Authentication & Authorization
- **Provider**: Replit Auth integration with OAuth 2.0/OpenID Connect
- **Session Storage**: PostgreSQL-backed sessions with automatic cleanup
- **Security**: HTTP-only cookies, CSRF protection, and secure session management
- **User Management**: Automatic user creation and profile management through auth provider

### AI & Analytics Services
- **Sentiment Analysis**: Custom keyword-based sentiment scoring for journal entries
- **AI Chatbot**: OpenAI GPT-4o integration for conversational support with context awareness
- **Insights Generation**: AI-powered analysis of user patterns and personalized recommendations
- **Data Processing**: Real-time sentiment analysis and mood trend calculations

## External Dependencies

### Core Infrastructure
- **Database**: Neon PostgreSQL serverless database for scalable data storage
- **Authentication**: Replit Auth service for user identity management
- **Hosting**: Replit platform for development and deployment

### AI & Machine Learning
- **OpenAI API**: GPT-4o model for chatbot responses and insight generation
- **Custom Sentiment Analysis**: Internal service using keyword-based sentiment scoring

### Development & Deployment
- **Package Manager**: npm for dependency management
- **Build System**: Vite for frontend bundling and development server
- **Type Safety**: TypeScript across the entire application stack
- **Database Toolkit**: Drizzle ORM and Drizzle Kit for schema management

### UI & Styling
- **Component Library**: Radix UI for accessible, unstyled components
- **CSS Framework**: Tailwind CSS for utility-first styling
- **Design System**: shadcn/ui for consistent component patterns
- **Icons**: Lucide React for consistent iconography

### Data & State Management
- **Server State**: TanStack Query for API state management and caching
- **Form Handling**: React Hook Form with Zod validation
- **Date Utilities**: date-fns for date manipulation and formatting