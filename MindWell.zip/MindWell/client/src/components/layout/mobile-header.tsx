import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Menu, X } from "lucide-react";

export default function MobileHeader() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
    const sidebar = document.getElementById('sidebar');
    if (sidebar) {
      if (isMobileMenuOpen) {
        sidebar.classList.add('-translate-x-64');
        sidebar.classList.remove('translate-x-0');
      } else {
        sidebar.classList.remove('-translate-x-64');
        sidebar.classList.add('translate-x-0');
      }
    }
  };

  return (
    <header className="lg:hidden fixed top-0 left-0 right-0 bg-white shadow-sm z-40 p-4">
      <div className="flex items-center justify-between">
        <Button
          variant="ghost"
          size="sm"
          onClick={toggleMobileMenu}
          className="p-2"
        >
          {isMobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
        </Button>
        <h1 className="text-lg font-semibold text-slate-800">StressSense</h1>
        <div className="w-8"></div>
      </div>
    </header>
  );
}
