import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { 
  Brain, BarChart3, BookOpen, Lightbulb, 
  MessageCircle, TrendingUp, Settings, LogOut 
} from "lucide-react";

export default function Sidebar() {
  const [location, setLocation] = useLocation();
  const { user } = useAuth();

  const navigation = [
    { name: "Dashboard", href: "/", icon: BarChart3, current: location === "/" },
    { name: "Mood Journal", href: "/journal", icon: BookOpen, current: location === "/journal" },
    { name: "Coping Strategies", href: "/strategies", icon: Lightbulb, current: location === "/strategies" },
    { name: "AI Companion", href: "/chatbot", icon: MessageCircle, current: location === "/chatbot" },
    { name: "Insights", href: "/insights", icon: TrendingUp, current: false }, // Coming soon
  ];

  return (
    <nav className="fixed left-0 top-0 h-full w-64 bg-white shadow-lg z-50 transform -translate-x-64 lg:translate-x-0 transition-transform duration-300" id="sidebar">
      <div className="p-6">
        {/* Logo */}
        <div className="flex items-center space-x-3 mb-10">
          <div className="w-10 h-10 stress-gradient-primary rounded-xl flex items-center justify-center">
            <Brain className="text-white" size={20} />
          </div>
          <h1 className="text-xl font-semibold text-slate-800">StressSense</h1>
        </div>
        
        {/* Navigation */}
        <ul className="space-y-2">
          {navigation.map((item) => (
            <li key={item.name}>
              <Button
                variant="ghost"
                className={`w-full justify-start space-x-3 p-2 h-auto ${
                  item.current
                    ? 'bg-[hsl(234,89%,69%)] text-white hover:bg-[hsl(234,89%,65%)]'
                    : 'text-slate-600 hover:bg-slate-50'
                }`}
                onClick={() => setLocation(item.href)}
              >
                <item.icon size={18} />
                <span>{item.name}</span>
              </Button>
            </li>
          ))}
        </ul>
      </div>
      
      {/* User Profile */}
      <div className="absolute bottom-6 left-6 right-6">
        <div className="p-4 bg-slate-50 rounded-lg">
          <div className="flex items-center space-x-3 mb-2">
            <div className="w-8 h-8 bg-slate-300 rounded-full flex items-center justify-center">
              {(user as any)?.profileImageUrl ? (
                <img 
                  src={(user as any).profileImageUrl} 
                  alt="Profile" 
                  className="w-8 h-8 rounded-full object-cover" 
                />
              ) : (
                <span className="text-slate-600 text-sm font-medium">
                  {(user as any)?.firstName?.[0]?.toUpperCase() || 'U'}
                </span>
              )}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-slate-800 truncate">
                {(user as any)?.firstName && (user as any)?.lastName 
                  ? `${(user as any).firstName} ${(user as any).lastName}`
                  : (user as any)?.email || 'User'
                }
              </p>
              <p className="text-xs text-slate-500">Student</p>
            </div>
          </div>
          
          <div className="flex space-x-2">
            <Button
              size="sm"
              variant="ghost"
              className="text-xs text-slate-600 hover:text-slate-800 p-1 h-auto"
            >
              <Settings size={14} className="mr-1" />
              Settings
            </Button>
            <Button
              size="sm"
              variant="ghost"
              className="text-xs text-slate-600 hover:text-slate-800 p-1 h-auto"
              onClick={() => window.location.href = '/api/logout'}
            >
              <LogOut size={14} className="mr-1" />
              Logout
            </Button>
          </div>
        </div>
      </div>
    </nav>
  );
}
