import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Smile, Heart, Moon, Book, TrendingUp, TrendingDown } from "lucide-react";

interface UserStats {
  avgMood: number;
  avgStress: number;
  avgSleep: number;
  totalStudyHours: number;
}

export default function StatsCards() {
  const { data: stats, isLoading } = useQuery<UserStats>({
    queryKey: ["/api/analytics/stats"],
  });

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {[...Array(4)].map((_, i) => (
          <Card key={i} className="border-slate-200 shadow-sm animate-pulse">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-slate-200 rounded-xl"></div>
                <div className="w-12 h-6 bg-slate-200 rounded"></div>
              </div>
              <div className="w-20 h-4 bg-slate-200 rounded mb-1"></div>
              <div className="w-16 h-3 bg-slate-200 rounded"></div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const cards = [
    {
      title: "Current Mood",
      value: stats?.avgMood?.toFixed(1) || "0.0",
      change: "+0.8 from yesterday",
      positive: true,
      icon: <Smile className="text-white" size={20} />,
      gradient: "stress-gradient-primary",
    },
    {
      title: "Stress Level", 
      value: stats?.avgStress?.toFixed(1) || "0.0",
      change: "-1.2 from yesterday",
      positive: true,
      icon: <Heart className="text-white" size={20} />,
      gradient: "stress-gradient-accent",
    },
    {
      title: "Sleep Quality",
      value: `${stats?.avgSleep?.toFixed(1) || "0.0"}/10`,
      change: "Good night's rest",
      positive: true,
      icon: <Moon className="text-white" size={20} />,
      gradient: "stress-gradient-success",
    },
    {
      title: "Study Time",
      value: `${stats?.totalStudyHours?.toFixed(1) || "0.0"}h`,
      change: "Total recorded hours",
      positive: null,
      icon: <Book className="text-white" size={20} />,
      gradient: "bg-gradient-to-r from-orange-500 to-yellow-500",
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {cards.map((card, index) => (
        <Card key={index} className="border-slate-200 shadow-sm hover:shadow-md transition-shadow">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className={`w-12 h-12 ${card.gradient} rounded-xl flex items-center justify-center`}>
                {card.icon}
              </div>
              <span className="text-2xl font-semibold text-slate-800">{card.value}</span>
            </div>
            <h3 className="text-sm font-medium text-slate-600 mb-1">{card.title}</h3>
            <p className={`text-xs flex items-center ${
              card.positive === true ? 'text-green-600' : 
              card.positive === false ? 'text-red-600' : 'text-slate-500'
            }`}>
              {card.positive === true && <TrendingUp size={12} className="mr-1" />}
              {card.positive === false && <TrendingDown size={12} className="mr-1" />}
              {card.change}
            </p>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
