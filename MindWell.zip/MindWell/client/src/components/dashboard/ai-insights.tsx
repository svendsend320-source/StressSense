import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Lightbulb, TrendingUp, Moon, Brain } from "lucide-react";

export default function AiInsights() {
  const { data: insights, isLoading } = useQuery<string[]>({
    queryKey: ["/api/analytics/insights"],
  });

  const defaultInsights = [
    {
      icon: <Lightbulb className="text-white" size={16} />,
      title: "Start Journaling",
      description: "Begin tracking your mood to unlock personalized insights and patterns.",
      iconBg: "bg-[hsl(207,73%,75%)]"
    }
  ];

  const getInsightIcon = (index: number) => {
    const icons = [
      { icon: <Lightbulb className="text-white" size={16} />, bg: "bg-[hsl(207,73%,75%)]" },
      { icon: <TrendingUp className="text-white" size={16} />, bg: "bg-[hsl(234,89%,69%)]" },
      { icon: <Moon className="text-white" size={16} />, bg: "bg-[hsl(0,77%,84%)]" },
      { icon: <Brain className="text-white" size={16} />, bg: "bg-[hsl(28,92%,84%)]" },
    ];
    return icons[index % icons.length];
  };

  if (isLoading) {
    return (
      <Card className="border-slate-200 shadow-sm">
        <CardContent className="p-6">
          <h3 className="text-lg font-semibold text-slate-800 mb-4">AI Insights</h3>
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="p-4 bg-slate-50 rounded-xl animate-pulse">
                <div className="flex items-start space-x-3">
                  <div className="w-8 h-8 bg-slate-200 rounded-full"></div>
                  <div className="flex-1">
                    <div className="h-4 bg-slate-200 rounded w-3/4 mb-2"></div>
                    <div className="h-3 bg-slate-200 rounded w-full"></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  const displayInsights = insights?.length 
    ? insights.map((insight, index) => ({
        ...getInsightIcon(index),
        title: "AI Insight",
        description: insight
      }))
    : defaultInsights;

  return (
    <Card className="border-slate-200 shadow-sm">
      <CardContent className="p-6">
        <h3 className="text-lg font-semibold text-slate-800 mb-4">AI Insights</h3>
        <div className="space-y-4">
          {displayInsights.map((insight, index) => (
            <div key={index} className="p-4 bg-slate-50 rounded-xl">
              <div className="flex items-start space-x-3">
                <div className={`w-8 h-8 ${(insight as any).bg || (insight as any).iconBg} rounded-full flex items-center justify-center flex-shrink-0`}>
                  {insight.icon}
                </div>
                <div>
                  <h4 className="text-sm font-medium text-slate-800 mb-1">{insight.title}</h4>
                  <p className="text-xs text-slate-600">{insight.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
