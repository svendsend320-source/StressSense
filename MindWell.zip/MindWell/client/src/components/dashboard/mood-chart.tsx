import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";

interface MoodTrend {
  date: string;
  moodScore: number;
  stressLevel: number | null;
}

export default function MoodChart() {
  const { data: trends, isLoading } = useQuery<MoodTrend[]>({
    queryKey: ["/api/analytics/mood-trends"],
    refetchInterval: false,
  });

  if (isLoading) {
    return (
      <Card className="border-slate-200 shadow-sm">
        <CardContent className="p-6">
          <h3 className="text-lg font-semibold text-slate-800 mb-4">Mood Trends (7 Days)</h3>
          <div className="h-64 flex items-end justify-between space-x-2 animate-pulse">
            {[...Array(7)].map((_, i) => (
              <div key={i} className="flex-1 bg-slate-200 rounded-t-lg" style={{ height: '45%' }}></div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  // Prepare data for the last 7 days
  const last7Days = [];
  for (let i = 6; i >= 0; i--) {
    const date = new Date();
    date.setDate(date.getDate() - i);
    last7Days.push(date);
  }

  const chartData = last7Days.map(date => {
    const dateStr = date.toISOString().split('T')[0];
    const entry = trends?.find(t => t.date.startsWith(dateStr));
    return {
      date,
      moodScore: entry?.moodScore || 0,
      dayLabel: date.toLocaleDateString('en-US', { weekday: 'short' })
    };
  });

  const maxMood = 5;

  return (
    <Card className="border-slate-200 shadow-sm">
      <CardContent className="p-6">
        <h3 className="text-lg font-semibold text-slate-800 mb-4">Mood Trends (7 Days)</h3>
        <div className="h-64 flex items-end justify-between space-x-2">
          {chartData.map((day, index) => {
            const height = (day.moodScore / maxMood) * 100;
            return (
              <div key={index} className="flex-1 flex flex-col items-center">
                <div
                  className="w-full stress-gradient-primary rounded-t-lg transition-all duration-300 hover:opacity-80"
                  style={{ height: `${Math.max(height, 5)}%` }}
                  title={`${day.dayLabel}: Mood ${day.moodScore}/5`}
                />
              </div>
            );
          })}
        </div>
        <div className="flex justify-between mt-2 text-xs text-slate-500">
          {chartData.map((day, index) => (
            <span key={index}>{day.dayLabel}</span>
          ))}
        </div>
        {trends?.length === 0 && (
          <div className="text-center py-8 text-slate-500">
            <p>No mood data yet. Start journaling to see your trends!</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
