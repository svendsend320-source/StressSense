import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import Sidebar from "@/components/layout/sidebar";
import MobileHeader from "@/components/layout/mobile-header";
import StatsCards from "@/components/dashboard/stats-cards";
import MoodChart from "@/components/dashboard/mood-chart";
import AiInsights from "@/components/dashboard/ai-insights";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useLocation } from "wouter";
import { Pen, Wind, Clock, MessageCircle } from "lucide-react";

export default function Home() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading, user } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-white">
      <Sidebar />
      <MobileHeader />
      
      <main className="lg:ml-64 pt-16 lg:pt-0">
        <section className="p-6 animate-fade-in">
          <div className="max-w-7xl mx-auto">
            {/* Header */}
            <div className="mb-8">
              <h2 className="text-2xl font-semibold text-slate-800 mb-2">
                Good {new Date().getHours() < 12 ? 'morning' : new Date().getHours() < 18 ? 'afternoon' : 'evening'}, {(user as any)?.firstName || 'there'}! 🌅
              </h2>
              <p className="text-slate-600">Let's check in on your wellbeing today</p>
            </div>

            {/* Stats Cards */}
            <StatsCards />

            {/* Charts and Insights */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
              <MoodChart />
              <AiInsights />
            </div>

            {/* Quick Actions */}
            <Card className="border-slate-200 shadow-sm">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold text-slate-800 mb-4">Quick Actions</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <Button
                    variant="outline"
                    className="p-4 h-auto flex flex-col items-center space-y-2 hover:bg-slate-50"
                    onClick={() => setLocation('/journal')}
                  >
                    <Pen className="text-[hsl(234,89%,69%)]" size={20} />
                    <span className="text-sm font-medium text-slate-800">Quick Journal</span>
                  </Button>
                  
                  <Button
                    variant="outline"
                    className="p-4 h-auto flex flex-col items-center space-y-2 hover:bg-slate-50"
                    onClick={() => setLocation('/strategies')}
                  >
                    <Wind className="text-[hsl(207,73%,75%)]" size={20} />
                    <span className="text-sm font-medium text-slate-800">Breathing Exercise</span>
                  </Button>
                  
                  <Button
                    variant="outline"
                    className="p-4 h-auto flex flex-col items-center space-y-2 hover:bg-slate-50"
                    onClick={() => setLocation('/strategies')}
                  >
                    <Clock className="text-[hsl(0,77%,84%)]" size={20} />
                    <span className="text-sm font-medium text-slate-800">Pomodoro Timer</span>
                  </Button>
                  
                  <Button
                    variant="outline"
                    className="p-4 h-auto flex flex-col items-center space-y-2 hover:bg-slate-50"
                    onClick={() => setLocation('/chatbot')}
                  >
                    <MessageCircle className="text-[hsl(28,92%,84%)]" size={20} />
                    <span className="text-sm font-medium text-slate-800">Talk to AI</span>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>
      </main>
    </div>
  );
}
