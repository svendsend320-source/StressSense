import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import Sidebar from "@/components/layout/sidebar";
import MobileHeader from "@/components/layout/mobile-header";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { 
  Wind, Clock, Target, Moon, Users, Dumbbell, 
  Lightbulb, Heart, Leaf, Music, Play, Pause, 
  RotateCcw, Timer
} from "lucide-react";

interface ActiveSession {
  type: string;
  title: string;
  description: string;
  duration: number; // in seconds
  icon: React.ReactNode;
}

export default function Strategies() {
  const { toast } = useToast();
  const [activeSession, setActiveSession] = useState<ActiveSession | null>(null);
  const [timeLeft, setTimeLeft] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const [sessionId, setSessionId] = useState<string | null>(null);

  const createSessionMutation = useMutation({
    mutationFn: async (data: { strategy: string; duration?: number }) => {
      return await apiRequest("POST", "/api/coping-sessions", data);
    },
    onSuccess: (data: any) => {
      setSessionId(data.id);
    },
  });

  const updateSessionMutation = useMutation({
    mutationFn: async (data: { id: string; updates: any }) => {
      return await apiRequest("PUT", `/api/coping-sessions/${data.id}`, data.updates);
    },
  });

  const startSession = (session: Omit<ActiveSession, 'duration'> & { duration: number }) => {
    setActiveSession(session);
    setTimeLeft(session.duration);
    setIsRunning(true);
    
    createSessionMutation.mutate({
      strategy: session.type,
      duration: Math.floor(session.duration / 60),
    });

    // Start countdown
    const interval = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          setIsRunning(false);
          setActiveSession(null);
          clearInterval(interval);
          
          // Mark session as completed
          if (sessionId) {
            updateSessionMutation.mutate({
              id: sessionId,
              updates: { completed: true }
            });
          }
          
          toast({
            title: "Session Complete!",
            description: "Great job! How do you feel?",
          });
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  };

  const pauseSession = () => {
    setIsRunning(!isRunning);
  };

  const stopSession = () => {
    setActiveSession(null);
    setTimeLeft(0);
    setIsRunning(false);
    
    if (sessionId) {
      updateSessionMutation.mutate({
        id: sessionId,
        updates: { completed: false }
      });
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const strategies = [
    {
      category: "Immediate Relief",
      icon: <Heart className="text-white" size={20} />,
      gradient: "stress-gradient-accent",
      items: [
        {
          type: "breathing-478",
          title: "4-7-8 Breathing",
          description: "5 minutes • Reduces anxiety",
          icon: <Wind />,
          duration: 300, // 5 minutes
        },
        {
          type: "progressive-relaxation",
          title: "Progressive Relaxation", 
          description: "10 minutes • Full body release",
          icon: <Leaf />,
          duration: 600, // 10 minutes
        },
        {
          type: "mindfulness",
          title: "Quick Mindfulness",
          description: "3 minutes • Present moment focus",
          icon: <Lightbulb />,
          duration: 180, // 3 minutes
        },
      ]
    },
    {
      category: "Focus & Productivity",
      icon: <Clock className="text-white" size={20} />,
      gradient: "stress-gradient-primary",
      items: [
        {
          type: "pomodoro",
          title: "Pomodoro Timer",
          description: "25 min work + 5 min break",
          icon: <Timer />,
          duration: 1500, // 25 minutes
        },
        {
          type: "focus-music",
          title: "Focus Music",
          description: "Binaural beats & ambient sounds",
          icon: <Music />,
          duration: 3600, // 60 minutes
        },
        {
          type: "study-goals",
          title: "Study Goals",
          description: "Break tasks into manageable chunks",
          icon: <Target />,
          duration: 0, // No timer
        },
      ]
    },
    {
      category: "Long-term Wellness",
      icon: <Leaf className="text-white" size={20} />,
      gradient: "stress-gradient-success",
      items: [
        {
          type: "sleep-schedule",
          title: "Sleep Schedule",
          description: "Optimize your sleep hygiene",
          icon: <Moon />,
          duration: 0,
        },
        {
          type: "exercise",
          title: "Physical Activity",
          description: "Quick workouts & walks",
          icon: <Dumbbell />,
          duration: 900, // 15 minutes
        },
        {
          type: "social-connection",
          title: "Social Connection",
          description: "Reach out to friends & family",
          icon: <Users />,
          duration: 0,
        },
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-white">
      <Sidebar />
      <MobileHeader />
      
      <main className="lg:ml-64 pt-16 lg:pt-0">
        <section className="p-6 animate-slide-up">
          <div className="max-w-6xl mx-auto">
            <div className="mb-8">
              <h2 className="text-2xl font-semibold text-slate-800 mb-2">Personalized Coping Strategies</h2>
              <p className="text-slate-600">AI-recommended activities based on your current stress level and preferences</p>
            </div>

            {/* Current Recommendation */}
            <Card className="border-none stress-gradient-primary text-white mb-8">
              <CardContent className="p-6">
                <div className="flex items-center space-x-4">
                  <div className="w-16 h-16 bg-white bg-opacity-20 rounded-2xl flex items-center justify-center">
                    <Wind size={32} />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl font-semibold mb-2">Recommended: 5-Minute Breathing Exercise</h3>
                    <p className="opacity-90">Based on your recent activity, a brief breathing exercise can help you refocus and relax.</p>
                  </div>
                  <Button
                    onClick={() => startSession({
                      type: "breathing-478",
                      title: "4-7-8 Breathing Exercise",
                      description: "Breathe in for 4, hold for 7, exhale for 8",
                      icon: <Wind />,
                      duration: 300,
                    })}
                    className="bg-white text-[hsl(234,89%,69%)] hover:bg-slate-50"
                  >
                    Start Now
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Strategy Categories */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
              {strategies.map((category, categoryIndex) => (
                <Card key={categoryIndex} className="border-slate-200 shadow-sm">
                  <CardContent className="p-6">
                    <div className={`w-12 h-12 ${category.gradient} rounded-xl flex items-center justify-center mb-4`}>
                      {category.icon}
                    </div>
                    <h3 className="text-lg font-semibold text-slate-800 mb-3">{category.category}</h3>
                    <div className="space-y-3">
                      {category.items.map((item, index) => (
                        <Button
                          key={index}
                          variant="outline"
                          className="w-full justify-start p-3 h-auto hover:bg-slate-50 border-slate-200"
                          onClick={() => {
                            if (item.duration > 0) {
                              startSession({
                                type: item.type,
                                title: item.title,
                                description: item.description,
                                icon: item.icon,
                                duration: item.duration,
                              });
                            } else {
                              toast({
                                title: item.title,
                                description: "Feature coming soon!",
                              });
                            }
                          }}
                        >
                          <div className="flex items-center space-x-3 w-full">
                            <div className="text-slate-600">{item.icon}</div>
                            <div className="text-left">
                              <p className="text-sm font-medium text-slate-800">{item.title}</p>
                              <p className="text-xs text-slate-500">{item.description}</p>
                            </div>
                          </div>
                        </Button>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Active Session Display */}
            {activeSession && (
              <Card className="border-slate-200 shadow-sm">
                <CardContent className="p-6">
                  <div className="text-center">
                    <div className="w-24 h-24 stress-gradient-primary rounded-full flex items-center justify-center mx-auto mb-4 animate-gentle-pulse">
                      <div className="text-white text-2xl">{activeSession.icon}</div>
                    </div>
                    <h3 className="text-xl font-semibold text-slate-800 mb-2">{activeSession.title}</h3>
                    <p className="text-slate-600 mb-6">{activeSession.description}</p>
                    
                    <div className="bg-slate-50 rounded-xl p-6 mb-6">
                      <div className="text-3xl font-bold text-[hsl(234,89%,69%)] mb-2">
                        {formatTime(timeLeft)}
                      </div>
                      <div className="text-sm text-slate-500">Time remaining</div>
                    </div>
                    
                    <div className="flex justify-center space-x-4">
                      <Button
                        variant="outline"
                        onClick={pauseSession}
                        className="border-slate-300 text-slate-700 hover:bg-slate-50"
                      >
                        {isRunning ? <Pause className="mr-2" size={16} /> : <Play className="mr-2" size={16} />}
                        {isRunning ? 'Pause' : 'Resume'}
                      </Button>
                      <Button
                        onClick={stopSession}
                        className="bg-[hsl(0,77%,84%)] hover:bg-[hsl(0,77%,80%)] text-white"
                      >
                        <RotateCcw className="mr-2" size={16} />
                        Stop
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </section>
      </main>
    </div>
  );
}
