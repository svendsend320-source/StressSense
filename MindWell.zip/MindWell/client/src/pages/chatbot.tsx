import { useState, useRef, useEffect } from "react";
import { useForm } from "react-hook-form";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { type ChatMessage } from "@shared/schema";
import Sidebar from "@/components/layout/sidebar";
import MobileHeader from "@/components/layout/mobile-header";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem } from "@/components/ui/form";
import { Badge } from "@/components/ui/badge";
import { Bot, User, Send, MessageCircle } from "lucide-react";
import { format } from "date-fns";
import { z } from "zod";

const messageSchema = z.object({
  content: z.string().min(1, "Message cannot be empty"),
});

type MessageFormData = z.infer<typeof messageSchema>;

export default function Chatbot() {
  const { toast } = useToast();
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [suggestions, setSuggestions] = useState<string[]>([]);

  const form = useForm<MessageFormData>({
    defaultValues: {
      content: "",
    },
  });

  const { data: messages, isLoading } = useQuery<ChatMessage[]>({
    queryKey: ["/api/chat"],
  });

  const sendMessageMutation = useMutation({
    mutationFn: async (data: MessageFormData) => {
      return await apiRequest("POST", "/api/chat", data);
    },
    onSuccess: (response: any) => {
      queryClient.invalidateQueries({ queryKey: ["/api/chat"] });
      setSuggestions(response.suggestions || []);
      form.reset();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: MessageFormData) => {
    sendMessageMutation.mutate(data);
  };

  const sendQuickMessage = (message: string) => {
    form.setValue("content", message);
    sendMessageMutation.mutate({ content: message });
  };

  const quickTopics = [
    { label: "Exam Anxiety", message: "I'm feeling anxious about my upcoming exams. Can you help?" },
    { label: "Time Management", message: "I'm struggling with managing my time effectively. Any tips?" },
    { label: "Motivation Tips", message: "I'm feeling unmotivated to study. How can I get back on track?" },
    { label: "Sleep Help", message: "I'm having trouble sleeping due to stress. What should I do?" },
  ];

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Add initial greeting if no messages
  const displayMessages = messages || [];
  const hasMessages = displayMessages.length > 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-white">
      <Sidebar />
      <MobileHeader />
      
      <main className="lg:ml-64 pt-16 lg:pt-0">
        <section className="p-6 animate-slide-up">
          <div className="max-w-4xl mx-auto">
            <div className="mb-8">
              <h2 className="text-2xl font-semibold text-slate-800 mb-2">AI Companion</h2>
              <p className="text-slate-600">A supportive AI friend to help you navigate academic stress</p>
            </div>

            {/* Chat Interface */}
            <Card className="border-slate-200 shadow-sm h-96 flex flex-col mb-6">
              {/* Chat Header */}
              <div className="p-4 border-b border-slate-200">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 stress-gradient-primary rounded-full flex items-center justify-center">
                    <Bot className="text-white" size={20} />
                  </div>
                  <div>
                    <h3 className="font-medium text-slate-800">Alex</h3>
                    <p className="text-sm text-green-600">Online • Always here for you</p>
                  </div>
                </div>
              </div>

              {/* Chat Messages */}
              <div className="flex-1 p-4 overflow-y-auto space-y-4">
                {!hasMessages && (
                  <div className="flex items-start space-x-3">
                    <div className="w-8 h-8 stress-gradient-primary rounded-full flex items-center justify-center flex-shrink-0">
                      <Bot className="text-white" size={16} />
                    </div>
                    <div className="bg-slate-50 rounded-xl p-3 max-w-xs">
                      <p className="text-sm text-slate-800">
                        Hi {(user as any)?.firstName || 'there'}! I'm Alex, your AI companion. I'm here to support you through academic stress. 
                        How are you feeling today?
                      </p>
                      <span className="text-xs text-slate-500 mt-1 block">
                        {format(new Date(), 'h:mm a')}
                      </span>
                    </div>
                  </div>
                )}

                {isLoading ? (
                  <div className="flex justify-center">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[hsl(234,89%,69%)]"></div>
                  </div>
                ) : (
                  displayMessages.map((message) => (
                    <div
                      key={message.id}
                      className={`flex items-start space-x-3 ${
                        message.isFromUser ? 'justify-end' : ''
                      }`}
                    >
                      {message.isFromUser ? (
                        <>
                          <div className="bg-[hsl(234,89%,69%)] rounded-xl p-3 max-w-xs text-white">
                            <p className="text-sm">{message.content}</p>
                            <span className="text-xs opacity-75 mt-1 block">
                              {format(new Date(message.createdAt!), 'h:mm a')}
                            </span>
                          </div>
                          <div className="w-8 h-8 bg-slate-300 rounded-full flex items-center justify-center flex-shrink-0">
                            <User className="text-slate-600" size={16} />
                          </div>
                        </>
                      ) : (
                        <>
                          <div className="w-8 h-8 stress-gradient-primary rounded-full flex items-center justify-center flex-shrink-0">
                            <Bot className="text-white" size={16} />
                          </div>
                          <div className="bg-slate-50 rounded-xl p-3 max-w-sm">
                            <p className="text-sm text-slate-800">{message.content}</p>
                            <span className="text-xs text-slate-500 mt-1 block">
                              {format(new Date(message.createdAt!), 'h:mm a')}
                            </span>
                          </div>
                        </>
                      )}
                    </div>
                  ))
                )}

                {/* Suggested Actions */}
                {suggestions.length > 0 && (
                  <div className="flex flex-wrap gap-2 justify-center">
                    {suggestions.map((suggestion, index) => (
                      <Button
                        key={index}
                        size="sm"
                        variant="outline"
                        className="text-xs border-[hsl(234,89%,69%)] text-[hsl(234,89%,69%)] hover:bg-[hsl(234,89%,69%)] hover:text-white"
                        onClick={() => sendQuickMessage(suggestion)}
                      >
                        {suggestion}
                      </Button>
                    ))}
                  </div>
                )}

                <div ref={messagesEndRef} />
              </div>

              {/* Chat Input */}
              <div className="p-4 border-t border-slate-200">
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="flex space-x-3">
                    <FormField
                      control={form.control}
                      name="content"
                      render={({ field }) => (
                        <FormItem className="flex-1">
                          <FormControl>
                            <Input
                              {...field}
                              placeholder="Type your message..."
                              className="border-slate-200 focus:ring-2 focus:ring-[hsl(234,89%,69%)] focus:border-transparent"
                              onKeyDown={(e) => {
                                if (e.key === 'Enter' && !e.shiftKey) {
                                  e.preventDefault();
                                  form.handleSubmit(onSubmit)();
                                }
                              }}
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    <Button
                      type="submit"
                      disabled={sendMessageMutation.isPending}
                      className="bg-[hsl(234,89%,69%)] hover:bg-[hsl(234,89%,65%)] text-white"
                    >
                      {sendMessageMutation.isPending ? (
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white" />
                      ) : (
                        <Send size={16} />
                      )}
                    </Button>
                  </form>
                </Form>
                <p className="text-xs text-slate-500 mt-2 text-center">
                  Alex uses AI to provide supportive responses. Remember, this isn't a replacement for professional help.
                </p>
              </div>
            </Card>

            {/* Quick Topics */}
            <Card className="border-slate-200 shadow-sm">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold text-slate-800 mb-4">Quick Topics</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {quickTopics.map((topic, index) => (
                    <Button
                      key={index}
                      variant="outline"
                      className="p-3 h-auto border-slate-200 hover:bg-slate-50 text-sm text-slate-800"
                      onClick={() => sendQuickMessage(topic.message)}
                    >
                      {topic.label}
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </section>
      </main>
    </div>
  );
}
