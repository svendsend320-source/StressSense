import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { insertJournalEntrySchema, type JournalEntry } from "@shared/schema";
import { z } from "zod";
import Sidebar from "@/components/layout/sidebar";
import MobileHeader from "@/components/layout/mobile-header";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Badge } from "@/components/ui/badge";
import { Save, Book, Moon, Heart } from "lucide-react";
import { format } from "date-fns";

const journalFormSchema = insertJournalEntrySchema.extend({
  studyHours: z.string().optional(),
  sleepQuality: z.string().optional(),
  stressLevel: z.string().optional(),
});

type JournalFormData = z.infer<typeof journalFormSchema>;

export default function Journal() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedMood, setSelectedMood] = useState<number | null>(null);

  const form = useForm<JournalFormData>({
    resolver: zodResolver(journalFormSchema),
    defaultValues: {
      content: "",
      moodScore: 3,
      studyHours: "",
      sleepQuality: "",
      stressLevel: "",
    },
  });

  const { data: journalEntries, isLoading } = useQuery<JournalEntry[]>({
    queryKey: ["/api/journal"],
  });

  const createEntryMutation = useMutation({
    mutationFn: async (data: JournalFormData) => {
      const payload = {
        ...data,
        moodScore: selectedMood || data.moodScore,
        studyHours: data.studyHours ? parseFloat(data.studyHours) : undefined,
        sleepQuality: data.sleepQuality ? parseInt(data.sleepQuality) : undefined,
        stressLevel: data.stressLevel ? parseInt(data.stressLevel) : undefined,
      };
      
      return await apiRequest("POST", "/api/journal", payload);
    },
    onSuccess: () => {
      toast({
        title: "Entry saved!",
        description: "Your journal entry has been analyzed and saved.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/journal"] });
      queryClient.invalidateQueries({ queryKey: ["/api/analytics"] });
      form.reset();
      setSelectedMood(null);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to save journal entry. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: JournalFormData) => {
    if (!selectedMood && !data.moodScore) {
      toast({
        title: "Please select your mood",
        description: "Choose how you're feeling today before saving.",
        variant: "destructive",
      });
      return;
    }
    createEntryMutation.mutate(data);
  };

  const moodEmojis = ["😢", "😟", "😐", "🙂", "😊"];
  const moodColors = [
    "bg-red-200 hover:bg-red-300 text-red-600",
    "bg-orange-200 hover:bg-orange-300 text-orange-600", 
    "bg-yellow-200 hover:bg-yellow-300 text-yellow-600",
    "bg-lime-200 hover:bg-lime-300 text-lime-600",
    "bg-green-200 hover:bg-green-300 text-green-600"
  ];

  const getSentimentBadge = (label: string | null) => {
    if (!label) return null;
    
    const colors = {
      positive: "bg-green-100 text-green-800",
      negative: "bg-red-100 text-red-800", 
      neutral: "bg-yellow-100 text-yellow-800"
    };
    
    return (
      <Badge className={colors[label as keyof typeof colors] || colors.neutral}>
        {label.charAt(0).toUpperCase() + label.slice(1)}
      </Badge>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-white">
      <Sidebar />
      <MobileHeader />
      
      <main className="lg:ml-64 pt-16 lg:pt-0">
        <section className="p-6 animate-slide-up">
          <div className="max-w-4xl mx-auto">
            <div className="mb-8">
              <h2 className="text-2xl font-semibold text-slate-800 mb-2">Daily Mood Journal</h2>
              <p className="text-slate-600">Take a moment to reflect on your day and emotions</p>
            </div>

            {/* Journal Entry Form */}
            <Card className="border-slate-200 shadow-sm mb-6">
              <CardContent className="p-6">
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    {/* Mood Selection */}
                    <div>
                      <Label className="text-sm font-medium text-slate-800 mb-2 block">
                        How are you feeling today?
                      </Label>
                      <div className="flex space-x-2 mb-4">
                        {moodEmojis.map((emoji, index) => (
                          <button
                            key={index}
                            type="button"
                            className={`w-12 h-12 rounded-full transition-all text-lg flex items-center justify-center ${
                              moodColors[index]
                            } ${
                              selectedMood === index + 1 
                                ? 'ring-4 ring-[hsl(234,89%,69%)] ring-opacity-50 scale-110' 
                                : ''
                            }`}
                            onClick={() => setSelectedMood(index + 1)}
                          >
                            {emoji}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Journal Content */}
                    <FormField
                      control={form.control}
                      name="content"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-slate-800">Tell me about your day...</FormLabel>
                          <FormControl>
                            <Textarea
                              {...field}
                              className="h-32 resize-none border-slate-200 focus:ring-2 focus:ring-[hsl(234,89%,69%)] focus:border-transparent"
                              placeholder="I felt... Today was challenging because... I'm grateful for..."
                            />
                          </FormControl>
                          <p className="text-xs text-slate-500">
                            AI will analyze the sentiment and emotional tone of your entry
                          </p>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Additional Metrics */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <FormField
                        control={form.control}
                        name="studyHours"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-slate-800">Study Hours</FormLabel>
                            <FormControl>
                              <Input
                                {...field}
                                type="number"
                                step="0.5"
                                placeholder="4.5"
                                className="border-slate-200 focus:ring-2 focus:ring-[hsl(234,89%,69%)] focus:border-transparent"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="sleepQuality"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-slate-800">Sleep Quality (1-10)</FormLabel>
                            <FormControl>
                              <Input
                                {...field}
                                type="number"
                                min="1"
                                max="10"
                                placeholder="8"
                                className="border-slate-200 focus:ring-2 focus:ring-[hsl(234,89%,69%)] focus:border-transparent"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="stressLevel"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-slate-800">Stress Level (1-10)</FormLabel>
                            <FormControl>
                              <Input
                                {...field}
                                type="number"
                                min="1"
                                max="10"
                                placeholder="4"
                                className="border-slate-200 focus:ring-2 focus:ring-[hsl(234,89%,69%)] focus:border-transparent"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <Button
                      type="submit"
                      disabled={createEntryMutation.isPending}
                      className="w-full bg-[hsl(234,89%,69%)] hover:bg-[hsl(234,89%,65%)] text-white"
                    >
                      {createEntryMutation.isPending ? (
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                      ) : (
                        <Save className="mr-2" size={16} />
                      )}
                      Save Entry & Analyze
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>

            {/* Previous Entries */}
            <Card className="border-slate-200 shadow-sm">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold text-slate-800 mb-4">Recent Entries</h3>
                
                {isLoading ? (
                  <div className="space-y-4">
                    {[...Array(3)].map((_, i) => (
                      <div key={i} className="p-4 bg-slate-50 rounded-xl animate-pulse">
                        <div className="h-4 bg-slate-200 rounded w-1/4 mb-2"></div>
                        <div className="h-3 bg-slate-200 rounded w-3/4 mb-2"></div>
                        <div className="h-3 bg-slate-200 rounded w-1/2"></div>
                      </div>
                    ))}
                  </div>
                ) : journalEntries?.length === 0 ? (
                  <div className="text-center py-8">
                    <Book className="mx-auto text-slate-400 mb-4" size={48} />
                    <p className="text-slate-500">No journal entries yet. Start by writing about your day!</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {journalEntries?.map((entry) => (
                      <div key={entry.id} className="p-4 bg-slate-50 rounded-xl">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center space-x-2">
                            <span className="text-2xl">{moodEmojis[entry.moodScore - 1]}</span>
                            <span className="text-sm font-medium text-slate-800">
                              {format(new Date(entry.date!), 'MMMM d, yyyy')}
                            </span>
                          </div>
                          <div className="flex items-center space-x-2">
                            {getSentimentBadge(entry.sentimentLabel)}
                            <span className="text-xs text-slate-500">
                              Mood: {entry.moodScore}/5
                            </span>
                          </div>
                        </div>
                        
                        <p className="text-sm text-slate-600 mb-2 line-clamp-2">
                          {entry.content}
                        </p>
                        
                        <div className="flex space-x-4 text-xs text-slate-500">
                          {entry.studyHours && (
                            <span className="flex items-center">
                              <Book className="mr-1" size={12} />
                              Study: {entry.studyHours}h
                            </span>
                          )}
                          {entry.sleepQuality && (
                            <span className="flex items-center">
                              <Moon className="mr-1" size={12} />
                              Sleep: {entry.sleepQuality}/10
                            </span>
                          )}
                          {entry.stressLevel && (
                            <span className="flex items-center">
                              <Heart className="mr-1" size={12} />
                              Stress: {entry.stressLevel}/10
                            </span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </section>
      </main>
    </div>
  );
}
