import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Brain, Heart, Moon, Clock, Users, TrendingUp } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-white">
      {/* Header */}
      <header className="p-6">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 stress-gradient-primary rounded-xl flex items-center justify-center">
              <Brain className="text-white" size={20} />
            </div>
            <h1 className="text-xl font-semibold text-slate-800">StressSense</h1>
          </div>
          
          <Button 
            onClick={() => window.location.href = '/api/login'}
            className="bg-[hsl(234,89%,69%)] hover:bg-[hsl(234,89%,65%)] text-white"
          >
            Get Started
          </Button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl md:text-6xl font-bold text-slate-800 mb-6">
            Take Control of Your 
            <span className="text-[hsl(234,89%,69%)]"> Academic Stress</span>
          </h2>
          <p className="text-xl text-slate-600 mb-8 max-w-2xl mx-auto">
            AI-powered mood tracking, personalized coping strategies, and empathetic support 
            to help you thrive during your academic journey.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg"
              onClick={() => window.location.href = '/api/login'}
              className="bg-[hsl(234,89%,69%)] hover:bg-[hsl(234,89%,65%)] text-white px-8 py-3"
            >
              Start Your Wellness Journey
            </Button>
            <Button 
              size="lg" 
              variant="outline"
              className="border-[hsl(234,89%,69%)] text-[hsl(234,89%,69%)] hover:bg-[hsl(234,89%,69%)] hover:text-white px-8 py-3"
            >
              Learn More
            </Button>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-20 px-6 bg-white">
        <div className="max-w-6xl mx-auto">
          <h3 className="text-3xl font-bold text-center text-slate-800 mb-12">
            Everything You Need to Manage Stress
          </h3>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="border-slate-200 hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="w-12 h-12 stress-gradient-primary rounded-xl flex items-center justify-center mb-4">
                  <Heart className="text-white" size={24} />
                </div>
                <h4 className="text-xl font-semibold text-slate-800 mb-2">Mood Tracking</h4>
                <p className="text-slate-600">
                  Daily journaling with AI-powered sentiment analysis to understand your emotional patterns.
                </p>
              </CardContent>
            </Card>

            <Card className="border-slate-200 hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="w-12 h-12 stress-gradient-success rounded-xl flex items-center justify-center mb-4">
                  <TrendingUp className="text-white" size={24} />
                </div>
                <h4 className="text-xl font-semibold text-slate-800 mb-2">Stress Dashboard</h4>
                <p className="text-slate-600">
                  Visualize trends in mood, study time, and sleep quality with beautiful, insightful charts.
                </p>
              </CardContent>
            </Card>

            <Card className="border-slate-200 hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="w-12 h-12 stress-gradient-accent rounded-xl flex items-center justify-center mb-4">
                  <Clock className="text-white" size={24} />
                </div>
                <h4 className="text-xl font-semibold text-slate-800 mb-2">Coping Strategies</h4>
                <p className="text-slate-600">
                  Personalized recommendations including breathing exercises, Pomodoro timers, and focus music.
                </p>
              </CardContent>
            </Card>

            <Card className="border-slate-200 hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl flex items-center justify-center mb-4">
                  <Users className="text-white" size={24} />
                </div>
                <h4 className="text-xl font-semibold text-slate-800 mb-2">AI Companion</h4>
                <p className="text-slate-600">
                  Chat with Alex, your empathetic AI friend who understands academic stress and offers support.
                </p>
              </CardContent>
            </Card>

            <Card className="border-slate-200 hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-teal-500 rounded-xl flex items-center justify-center mb-4">
                  <Moon className="text-white" size={24} />
                </div>
                <h4 className="text-xl font-semibold text-slate-800 mb-2">Sleep & Wellness</h4>
                <p className="text-slate-600">
                  Track sleep quality and receive insights on how it affects your stress and academic performance.
                </p>
              </CardContent>
            </Card>

            <Card className="border-slate-200 hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-gradient-to-r from-orange-500 to-red-500 rounded-xl flex items-center justify-center mb-4">
                  <Brain className="text-white" size={24} />
                </div>
                <h4 className="text-xl font-semibold text-slate-800 mb-2">AI Insights</h4>
                <p className="text-slate-600">
                  Get intelligent insights about your stress patterns and personalized suggestions for improvement.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-6 bg-gradient-to-r from-[hsl(234,89%,69%)] to-[hsl(223,90%,82%)]">
        <div className="max-w-4xl mx-auto text-center">
          <h3 className="text-3xl font-bold text-white mb-6">
            Ready to Transform Your Academic Experience?
          </h3>
          <p className="text-xl text-blue-100 mb-8">
            Join thousands of students who are already managing stress better with StressSense.
          </p>
          
          <Button 
            size="lg"
            onClick={() => window.location.href = '/api/login'}
            className="bg-white text-[hsl(234,89%,69%)] hover:bg-slate-50 px-8 py-3 font-semibold"
          >
            Start Free Today
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-6 bg-slate-50">
        <div className="max-w-6xl mx-auto text-center">
          <div className="flex items-center justify-center space-x-3 mb-4">
            <div className="w-8 h-8 stress-gradient-primary rounded-lg flex items-center justify-center">
              <Brain className="text-white" size={16} />
            </div>
            <span className="text-lg font-semibold text-slate-800">StressSense</span>
          </div>
          <p className="text-slate-600">
            Empowering students to manage academic stress with AI-powered insights and personalized support.
          </p>
        </div>
      </footer>
    </div>
  );
}
