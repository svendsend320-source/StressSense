import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || ""
});

interface ChatbotResponse {
  message: string;
  suggestions?: string[];
}

export async function generateChatbotResponse(
  userMessage: string,
  context?: {
    recentMood?: number;
    stressLevel?: number;
    recentEntries?: string[];
  }
): Promise<ChatbotResponse> {
  try {
    const systemPrompt = `You are Alex, a supportive AI companion for StressSense, an academic stress management app. You provide empathetic, helpful responses to students dealing with academic stress.

Your personality:
- Warm, understanding, and supportive
- Knowledgeable about stress management and study techniques
- Encouraging but realistic
- Never give medical advice - always suggest professional help for serious concerns

Guidelines:
- Keep responses concise but thoughtful (2-3 sentences max)
- Offer practical, actionable suggestions
- Acknowledge their feelings
- Suggest specific coping strategies when appropriate
- If they seem very distressed, gently suggest talking to a counselor

${context ? `User context:
- Recent mood: ${context.recentMood}/5
- Stress level: ${context.stressLevel}/10
- Recent journal themes: ${context.recentEntries?.join(', ') || 'None'}` : ''}

Respond with JSON in this format: { "message": "your response", "suggestions": ["suggestion1", "suggestion2"] }`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userMessage }
      ],
      response_format: { type: "json_object" },
      max_tokens: 300,
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    
    return {
      message: result.message || "I'm here to help. Can you tell me more about what's going on?",
      suggestions: result.suggestions || []
    };
  } catch (error) {
    console.error('OpenAI API error:', error);
    return {
      message: "I'm having trouble connecting right now. In the meantime, try taking a few deep breaths or writing in your journal.",
      suggestions: ["Take deep breaths", "Write in journal", "Take a short walk"]
    };
  }
}

export async function generateInsights(journalEntries: Array<{
  content: string;
  moodScore: number;
  stressLevel?: number;
  date: Date;
}>): Promise<string[]> {
  try {
    const entrySummary = journalEntries.map(entry => 
      `${entry.date.toDateString()}: Mood ${entry.moodScore}/5, Stress ${entry.stressLevel || 'N/A'}/10 - "${entry.content.substring(0, 100)}..."`
    ).join('\n');

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `You are an AI that analyzes journal entries to provide helpful insights about stress patterns and wellbeing trends. Provide 2-3 actionable insights based on the data. Be encouraging and focus on positive patterns or helpful suggestions.

Respond with JSON in this format: { "insights": ["insight1", "insight2", "insight3"] }`
        },
        {
          role: "user",
          content: `Analyze these recent journal entries and provide insights:\n\n${entrySummary}`
        }
      ],
      response_format: { type: "json_object" },
      max_tokens: 200,
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    return result.insights || ["Keep tracking your mood to identify patterns over time."];
  } catch (error) {
    console.error('OpenAI insights error:', error);
    return ["Keep tracking your mood to identify patterns over time."];
  }
}
