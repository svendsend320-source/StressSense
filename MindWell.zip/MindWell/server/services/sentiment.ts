// Simple sentiment analysis service
// In production, you might want to use a more sophisticated NLP library
// For now, we'll implement a basic keyword-based sentiment analysis

interface SentimentResult {
  score: number; // -1 to 1
  label: 'positive' | 'negative' | 'neutral';
  confidence: number; // 0 to 1
}

const positiveWords = [
  'happy', 'joy', 'excited', 'great', 'awesome', 'fantastic', 'wonderful', 'amazing',
  'good', 'better', 'best', 'excellent', 'perfect', 'love', 'like', 'enjoy',
  'peaceful', 'calm', 'relaxed', 'confident', 'proud', 'grateful', 'thankful',
  'accomplished', 'successful', 'motivated', 'inspired', 'energetic', 'positive'
];

const negativeWords = [
  'sad', 'depressed', 'anxious', 'worried', 'stressed', 'frustrated', 'angry',
  'terrible', 'awful', 'horrible', 'bad', 'worse', 'worst', 'hate', 'dislike',
  'overwhelmed', 'exhausted', 'tired', 'lonely', 'afraid', 'scared', 'nervous',
  'disappointed', 'upset', 'confused', 'lost', 'hopeless', 'negative', 'difficult'
];

const stressWords = [
  'exam', 'test', 'deadline', 'assignment', 'project', 'study', 'studying',
  'pressure', 'busy', 'overwhelming', 'cramming', 'behind', 'late', 'rush'
];

export function analyzeSentiment(text: string): SentimentResult {
  const words = text.toLowerCase().split(/\W+/);
  
  let positiveCount = 0;
  let negativeCount = 0;
  let stressCount = 0;
  
  words.forEach(word => {
    if (positiveWords.includes(word)) {
      positiveCount++;
    }
    if (negativeWords.includes(word)) {
      negativeCount++;
    }
    if (stressWords.includes(word)) {
      stressCount++;
    }
  });
  
  // Calculate raw score
  const totalSentimentWords = positiveCount + negativeCount;
  let score = 0;
  
  if (totalSentimentWords > 0) {
    score = (positiveCount - negativeCount) / totalSentimentWords;
  }
  
  // Adjust for stress indicators
  if (stressCount > 0) {
    score -= (stressCount * 0.1);
  }
  
  // Clamp score between -1 and 1
  score = Math.max(-1, Math.min(1, score));
  
  // Determine label
  let label: 'positive' | 'negative' | 'neutral';
  if (score > 0.1) {
    label = 'positive';
  } else if (score < -0.1) {
    label = 'negative';
  } else {
    label = 'neutral';
  }
  
  // Calculate confidence based on number of sentiment words found
  const confidence = Math.min(1, totalSentimentWords / 10);
  
  return {
    score,
    label,
    confidence
  };
}
