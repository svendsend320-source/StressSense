import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { analyzeSentiment } from "./services/sentiment";
import { generateChatbotResponse, generateInsights } from "./services/openai";
import { insertJournalEntrySchema, insertChatMessageSchema, insertCopingSessionSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Journal routes
  app.post('/api/journal', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const validatedData = insertJournalEntrySchema.parse(req.body);
      
      // Create journal entry
      const entry = await storage.createJournalEntry(userId, validatedData);
      
      // Analyze sentiment
      const sentiment = analyzeSentiment(validatedData.content);
      await storage.updateJournalEntrySentiment(
        entry.id,
        sentiment.score,
        sentiment.label
      );
      
      res.json({ ...entry, sentimentScore: sentiment.score, sentimentLabel: sentiment.label });
    } catch (error) {
      console.error("Error creating journal entry:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create journal entry" });
      }
    }
  });

  app.get('/api/journal', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
      const entries = await storage.getUserJournalEntries(userId, limit);
      res.json(entries);
    } catch (error) {
      console.error("Error fetching journal entries:", error);
      res.status(500).json({ message: "Failed to fetch journal entries" });
    }
  });

  // Chat routes
  app.post('/api/chat', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { content } = req.body;
      
      if (!content || typeof content !== 'string') {
        return res.status(400).json({ message: "Message content is required" });
      }

      // Save user message
      await storage.createChatMessage(userId, {
        content,
        isFromUser: true
      });

      // Get user context for better responses
      const recentEntries = await storage.getUserJournalEntries(userId, 3);
      const stats = await storage.getUserStats(userId);
      
      const context = {
        recentMood: stats.avgMood,
        stressLevel: stats.avgStress,
        recentEntries: recentEntries.map(entry => entry.content.substring(0, 100))
      };

      // Generate AI response
      const aiResponse = await generateChatbotResponse(content, context);
      
      // Save AI message
      const aiMessage = await storage.createChatMessage(userId, {
        content: aiResponse.message,
        isFromUser: false
      });

      res.json({
        message: aiMessage,
        suggestions: aiResponse.suggestions
      });
    } catch (error) {
      console.error("Error in chat:", error);
      res.status(500).json({ message: "Failed to process chat message" });
    }
  });

  app.get('/api/chat', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const messages = await storage.getUserChatMessages(userId);
      res.json(messages.reverse()); // Return in chronological order
    } catch (error) {
      console.error("Error fetching chat messages:", error);
      res.status(500).json({ message: "Failed to fetch chat messages" });
    }
  });

  // Coping session routes
  app.post('/api/coping-sessions', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const validatedData = insertCopingSessionSchema.parse(req.body);
      
      const session = await storage.createCopingSession(userId, validatedData);
      res.json(session);
    } catch (error) {
      console.error("Error creating coping session:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create coping session" });
      }
    }
  });

  app.put('/api/coping-sessions/:id', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      
      await storage.updateCopingSession(id, updates);
      res.json({ message: "Session updated successfully" });
    } catch (error) {
      console.error("Error updating coping session:", error);
      res.status(500).json({ message: "Failed to update coping session" });
    }
  });

  // Analytics routes
  app.get('/api/analytics/stats', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const stats = await storage.getUserStats(userId);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching user stats:", error);
      res.status(500).json({ message: "Failed to fetch user stats" });
    }
  });

  app.get('/api/analytics/mood-trends', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const days = req.query.days ? parseInt(req.query.days as string) : 7;
      const trends = await storage.getUserMoodTrends(userId, days);
      res.json(trends);
    } catch (error) {
      console.error("Error fetching mood trends:", error);
      res.status(500).json({ message: "Failed to fetch mood trends" });
    }
  });

  app.get('/api/analytics/insights', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const entries = await storage.getUserJournalEntries(userId, 7);
      
      if (entries.length === 0) {
        return res.json([]);
      }

      const insights = await generateInsights(entries.map(entry => ({
        content: entry.content,
        moodScore: entry.moodScore,
        stressLevel: entry.stressLevel || undefined,
        date: entry.date!
      })));
      
      res.json(insights);
    } catch (error) {
      console.error("Error generating insights:", error);
      res.status(500).json({ message: "Failed to generate insights" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
