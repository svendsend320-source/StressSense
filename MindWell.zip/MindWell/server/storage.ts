import {
  users,
  journalEntries,
  chatMessages,
  copingSessions,
  type User,
  type UpsertUser,
  type JournalEntry,
  type InsertJournalEntry,
  type ChatMessage,
  type InsertChatMessage,
  type CopingSession,
  type InsertCopingSession,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, gte } from "drizzle-orm";

export interface IStorage {
  // User operations (required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Journal operations
  createJournalEntry(userId: string, entry: InsertJournalEntry): Promise<JournalEntry>;
  getUserJournalEntries(userId: string, limit?: number): Promise<JournalEntry[]>;
  updateJournalEntrySentiment(id: string, sentimentScore: number, sentimentLabel: string): Promise<void>;
  
  // Chat operations
  createChatMessage(userId: string, message: InsertChatMessage): Promise<ChatMessage>;
  getUserChatMessages(userId: string, limit?: number): Promise<ChatMessage[]>;
  
  // Coping session operations
  createCopingSession(userId: string, session: InsertCopingSession): Promise<CopingSession>;
  updateCopingSession(id: string, updates: Partial<CopingSession>): Promise<void>;
  getUserCopingSessions(userId: string, days?: number): Promise<CopingSession[]>;
  
  // Analytics operations
  getUserMoodTrends(userId: string, days: number): Promise<Array<{ date: Date; moodScore: number; stressLevel: number | null }>>;
  getUserStats(userId: string): Promise<{
    avgMood: number;
    avgStress: number;
    avgSleep: number;
    totalStudyHours: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Journal operations
  async createJournalEntry(userId: string, entry: InsertJournalEntry): Promise<JournalEntry> {
    const [journalEntry] = await db
      .insert(journalEntries)
      .values({
        ...entry,
        userId,
      })
      .returning();
    return journalEntry;
  }

  async getUserJournalEntries(userId: string, limit = 10): Promise<JournalEntry[]> {
    return await db
      .select()
      .from(journalEntries)
      .where(eq(journalEntries.userId, userId))
      .orderBy(desc(journalEntries.date))
      .limit(limit);
  }

  async updateJournalEntrySentiment(id: string, sentimentScore: number, sentimentLabel: string): Promise<void> {
    await db
      .update(journalEntries)
      .set({
        sentimentScore: sentimentScore.toString(),
        sentimentLabel,
      })
      .where(eq(journalEntries.id, id));
  }

  // Chat operations
  async createChatMessage(userId: string, message: InsertChatMessage): Promise<ChatMessage> {
    const [chatMessage] = await db
      .insert(chatMessages)
      .values({
        ...message,
        userId,
      })
      .returning();
    return chatMessage;
  }

  async getUserChatMessages(userId: string, limit = 50): Promise<ChatMessage[]> {
    return await db
      .select()
      .from(chatMessages)
      .where(eq(chatMessages.userId, userId))
      .orderBy(desc(chatMessages.createdAt))
      .limit(limit);
  }

  // Coping session operations
  async createCopingSession(userId: string, session: InsertCopingSession): Promise<CopingSession> {
    const [copingSession] = await db
      .insert(copingSessions)
      .values({
        ...session,
        userId,
      })
      .returning();
    return copingSession;
  }

  async updateCopingSession(id: string, updates: Partial<CopingSession>): Promise<void> {
    await db
      .update(copingSessions)
      .set(updates)
      .where(eq(copingSessions.id, id));
  }

  async getUserCopingSessions(userId: string, days = 30): Promise<CopingSession[]> {
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);

    return await db
      .select()
      .from(copingSessions)
      .where(
        and(
          eq(copingSessions.userId, userId),
          gte(copingSessions.createdAt, startDate)
        )
      )
      .orderBy(desc(copingSessions.createdAt));
  }

  // Analytics operations
  async getUserMoodTrends(userId: string, days: number): Promise<Array<{ date: Date; moodScore: number; stressLevel: number | null }>> {
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);

    const entries = await db
      .select({
        date: journalEntries.date,
        moodScore: journalEntries.moodScore,
        stressLevel: journalEntries.stressLevel,
      })
      .from(journalEntries)
      .where(
        and(
          eq(journalEntries.userId, userId),
          gte(journalEntries.date, startDate)
        )
      )
      .orderBy(journalEntries.date);

    return entries.map(entry => ({
      date: entry.date!,
      moodScore: entry.moodScore,
      stressLevel: entry.stressLevel,
    }));
  }

  async getUserStats(userId: string): Promise<{
    avgMood: number;
    avgStress: number;
    avgSleep: number;
    totalStudyHours: number;
  }> {
    const entries = await db
      .select()
      .from(journalEntries)
      .where(eq(journalEntries.userId, userId));

    if (entries.length === 0) {
      return {
        avgMood: 0,
        avgStress: 0,
        avgSleep: 0,
        totalStudyHours: 0,
      };
    }

    const totalMood = entries.reduce((sum, entry) => sum + entry.moodScore, 0);
    const validStress = entries.filter(entry => entry.stressLevel !== null);
    const totalStress = validStress.reduce((sum, entry) => sum + entry.stressLevel!, 0);
    const validSleep = entries.filter(entry => entry.sleepQuality !== null);
    const totalSleep = validSleep.reduce((sum, entry) => sum + entry.sleepQuality!, 0);
    const totalStudy = entries.reduce((sum, entry) => sum + (parseFloat(entry.studyHours || '0')), 0);

    return {
      avgMood: Math.round((totalMood / entries.length) * 10) / 10,
      avgStress: validStress.length > 0 ? Math.round((totalStress / validStress.length) * 10) / 10 : 0,
      avgSleep: validSleep.length > 0 ? Math.round((totalSleep / validSleep.length) * 10) / 10 : 0,
      totalStudyHours: Math.round(totalStudy * 10) / 10,
    };
  }
}

export const storage = new DatabaseStorage();
